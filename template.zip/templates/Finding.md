<%*
// 1. Setup Configuration
const folderPath = "3. Findings"; 
const notesFilePath = "notes.md"; 
const sevMap = { "Low": "L", "Medium": "M", "High": "H"};

// 2. Get User Input
let sevChoice = await tp.system.suggester(["Low", "Medium", "High"], ["Low", "Medium", "High"]);
let sevPrefix = sevMap[sevChoice];
let vulnTitle = await tp.system.prompt("Enter Finding Title");
let cweID = await tp.system.prompt("Enter CWE (e.g., CWE-89)", "CWE-");
let cvssScore = await tp.system.prompt("Enter CVSS Score (e.g., 8.8)");

// 3. Logic to Find the Next Incremental Number
let files = app.vault.getMarkdownFiles().filter(f => f.path.startsWith(folderPath));
let existingNumbers = files
    .map(f => f.basename.match(new RegExp(`^${sevPrefix}(\\d+)`)))
    .filter(match => match)
    .map(match => parseInt(match[1]));

let nextNum = existingNumbers.length > 0 ? Math.max(...existingNumbers) + 1 : 1;
let findingID = `${sevPrefix}${nextNum}`;
let finalFileName = `${findingID} - ${vulnTitle}`;

// 4. Move and Rename
await tp.file.move(`${folderPath}/${finalFileName}`);

// 5. Append to notes.md
const logFile = app.vault.getAbstractFileByPath(notesFilePath);
if (logFile) {
    const timestamp = tp.date.now("YYYY-MM-DD HH:mm");
    const logEntry = `\n- **${timestamp}**: New #finding [[${finalFileName}|${findingID}]] - ${vulnTitle} (CVSS: ${cvssScore})\n`;
    await app.vault.process(logFile, (data) => data + logEntry);
}
%>
# [<% findingID %>] <% vulnTitle %>

**Severity:** <% sevChoice %> | **CVSS:** <% cvssScore %> | **CWE:** <% cweID %>

## Description
## Impact
## Reproduction Steps
1. **Discovery:**
   - 
2. **Exploitation:**
   - 
3. **Proof:**
   - [ ] IP Address visible in screenshot
   - [ ] Flag content visible in screenshot
   - [ ] Current user context (`whoami`) visible

## Remediation