<%*
// 1. Setup Configuration
const hostFolder = "2. Hosts"; 
const notesFilePath = "notes.md"; 

// Mapping your specific types to Prefixes
const typeMap = {
    "Web": "WS",
    "Host": "HS",
    "DC": "DC"
};

// 2. Get User Input
let typeChoice = await tp.system.suggester(["Web", "Host", "DC"], ["Web", "Host", "DC"]);
let prefix = typeMap[typeChoice];
let machine = await tp.system.prompt("Enter Machine Title");
let ip = await tp.system.prompt("Enter IP Address");

// 3. Incrementing Logic
let files = app.vault.getMarkdownFiles().filter(f => f.path.startsWith(hostFolder));
let existingNumbers = files
    .map(f => f.basename.match(new RegExp(`^${prefix}(\\d+)`)))
    .filter(match => match)
    .map(match => parseInt(match[1]));

let nextNum = existingNumbers.length > 0 ? Math.max(...existingNumbers) + 1 : 1;
let hostID = `${prefix}${nextNum}`;
let finalFileName = `${hostID} - ${machine}`;

// 4. Move and Rename
await tp.file.move(`${hostFolder}/${finalFileName}`);

// 5. Append to AEN/notes.md
const logFile = app.vault.getAbstractFileByPath(notesFilePath);
if (logFile) {
    const timestamp = tp.date.now("YYYY-MM-DD HH:mm");
    const logEntry = `\n- **${timestamp}**: Discovery started on [[${finalFileName}|${hostID}]] (${machine}) - ${ip}\n`;
    await app.vault.process(logFile, (data) => data + logEntry);
}
-%>
## <% machine %>

**IP:** <% ip %>
**Hostname:** <% machine %>
**Domain:** 
**OS:** (guess from nmap)
**Tags:** #machine #<% typeChoice.toLowerCase().replace(" ", "-") %>

## 1. Recon / Service Discovery
- Nmap full: `nmap -p- -sV -sC -A <% ip %>`

## 2. Enumeration
- [ ] Port Scan
- [ ] Service Identification

## 3. Exploitation / Access


## 4. Post-Exploitation
- [ ] Local Recon
- [ ] PrivEsc
